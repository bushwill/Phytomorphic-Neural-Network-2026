#ifndef __LPFGALL_H__
#define __LPFGALL_H__

#pragma L2C start

#include <memory.h>
#include <stdlib.h>
#include <stdio.h>
#include "lparams.h"
#include "lintrfc.h"
#include "lsys.h"
#include "stdmods.h"

#else
#error File already included
#endif
